from django.shortcuts import render
from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string
from django.contrib import messages

  # the index function is called when root is visited
def index(request):
    if 'counter' not in request.session:
        request.session['counter']=0
    request.session['counter']+=1
    messages.add_message(request, messages.SUCCESS, 'Thanks for submitting this form! You have submitted this form' + str(request.session['counter'] ) + ' times in a row.')
    return render(request,'surveyform_app/index.html')


def result(request):
    request.session['name'] = request.POST['name']
    request.session['location'] = request.POST['location']
    request.session['language'] = request.POST['language']
    request.session['comment'] = request.POST['comment']
    print "result route"
    print request.POST
    return render(request,'surveyform_app/result.html')
   